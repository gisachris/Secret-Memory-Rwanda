/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-pages-browser)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fproject%2Fapp%2Fcomponents%2FFolderGrid.tsx&modules=%2Fhome%2Fproject%2Fapp%2Fcomponents%2FHero.tsx&server=false!":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fproject%2Fapp%2Fcomponents%2FFolderGrid.tsx&modules=%2Fhome%2Fproject%2Fapp%2Fcomponents%2FHero.tsx&server=false! ***!
  \*****************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/components/FolderGrid.tsx */ \"(app-pages-browser)/./app/components/FolderGrid.tsx\"));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/components/Hero.tsx */ \"(app-pages-browser)/./app/components/Hero.tsx\"))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvYnVpbGQvd2VicGFjay9sb2FkZXJzL25leHQtZmxpZ2h0LWNsaWVudC1lbnRyeS1sb2FkZXIuanM/bW9kdWxlcz0lMkZob21lJTJGcHJvamVjdCUyRmFwcCUyRmNvbXBvbmVudHMlMkZGb2xkZXJHcmlkLnRzeCZtb2R1bGVzPSUyRmhvbWUlMkZwcm9qZWN0JTJGYXBwJTJGY29tcG9uZW50cyUyRkhlcm8udHN4JnNlcnZlcj1mYWxzZSEiLCJtYXBwaW5ncyI6IkFBQUEsd0xBQWdGO0FBQ2hGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8/NjQ2NCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9ob21lL3Byb2plY3QvYXBwL2NvbXBvbmVudHMvRm9sZGVyR3JpZC50c3hcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9ob21lL3Byb2plY3QvYXBwL2NvbXBvbmVudHMvSGVyby50c3hcIikiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(app-pages-browser)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2Fhome%2Fproject%2Fapp%2Fcomponents%2FFolderGrid.tsx&modules=%2Fhome%2Fproject%2Fapp%2Fcomponents%2FHero.tsx&server=false!\n"));

/***/ })

});